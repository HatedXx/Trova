<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["adloggedin"]) || $_SESSION["adloggedin"] !== true){
    header("location: adlogin");
    exit;
}
require_once "config.php";
include ("include/connection.php");

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="css/app.46643acf.css" rel="preload" as="style">
<link href="css/chunk-vendors.cf06751b.css" rel="preload" as="style">
<link href="js/chunk-vendors.824d6eef.js" rel="preload" as="script">
<link href="css/chunk-vendors.cf06751b.css" rel="stylesheet">
<link href="css/app.46643acf.css" rel="stylesheet">
<style>
   #copied{
            visibility: hidden;
            min-width: 250px;
            margin-left: -125px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 16px;
            position: fixed;
            z-index: 1;
            left: 50%;
            bottom: 50px;
            font-size: 17px;
        }

       

        #copied.show {
            visibility: visible;
            margin-bottom: 205px;
            -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
            animation: fadein 0.5s, fadeout 0.5s 2.5s;
        }

        @-webkit-keyframes fadein {
            from {
                bottom: 0;
                opacity: 0;
            }

            to {
                bottom: 30px;
                opacity: 1;
            }
        }

        @keyframes fadein {
            from {
                bottom: 0;
                opacity: 0;
            }

            to {
                bottom: 30px;
                opacity: 1;
            }
        }

        @-webkit-keyframes fadeout {
            from {
                bottom: 30px;
                opacity: 1;
            }

            to {
                bottom: 0;
                opacity: 0;
            }
        }

        @keyframes fadeout {
            from {
                bottom: 30px;
                opacity: 1;
            }

            to {
                bottom: 0;
                opacity: 0;
            }
        }
     
body {
    font-family: "Lato", sans-serif;
  }
  
  .sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
  }
  
  .sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
  }
  
  .sidenav a:hover {
    color: #f1f1f1;
  }
  
  .sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
  }
  
  #main {
    transition: margin-left .5s;
    padding: 16px;
  }
  
  @media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
    .sidenav a {font-size: 18px;}
  }

</style>
</head>
<body>

 <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>

  <div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="admin" class="active" >Admin</a>
   <a href="users"  >Users</a>
  <a href="adduser">add User</a>
  <a href="inviterec">Invite Record</a>
  <a href="adpass">Password Change </a>
  <a href="adwith">Withdraw Requests</a>
  <a href="adpre">Next Predition</a>
  <a href="adreward">Reward Management</a>
  <a href="rechargeRequests">Recharge Requests</a>
  <a href="delete">Delete User</a>
  <a href="adlogout">Log Out</a>


</div>

 <!-- Main content -->
    <section class="content">
      <div class="row">
      <div class="col-xs-12 text-center">
          
          <?php if(isset($_GET['msg'])=="updt"){ ?>
              <span class="text-center red_txt">Update Successfully......</span><?php  } ?></div>
        <div class="col-xs-12">
          

          <div class="box">
            
            <!-- /.box-header -->


          
 <?php  

            
//  $sql="select* FROM `tbl_adminenvlop` order by id desc";

// $query=mysqli_query($con,$sql);

// $role=mysqli_fetch_array($query);

if(isset($_POST['envelopee'])=='Submit'){


  $redamt=($_POST['noenv']);
   
  $rednum=($_POST['amtenv']);

$sql= mysqli_query($con,"INSERT INTO `tbl_adminenvlop`(noenv, amtenv) VALUES ('$redamt','$rednum')");

   echo '<script>
        alert(" Insert ........");
        window.location.href="envelopee.php";
        </script>' ;

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

// $sql= "UPDATE `tbl_paymentsetting` SET `rednum` = '$rednum',`redamt` = '$redamt' WHERE `id`= '1'";

// $query=mysqli_query($con,$sql);

// if($query){

  

   echo '<script>
        alert("Setting Updating...");
        window.location.href="manage_amount.php";
        </script>' ;

  }


 ?>
      <form id="formID" name="formID" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">

            <div class="box-body">

<div class="clearfix"></div>







  <div class="col-sm-6">

              <div class="form-group">

              <label>Number OF USER</label>

              <input type="text" class="form-control"  name="noenv" id="noenv" required value="<?php echo $role['noenv'];?>">

              </div>

              </div> 
              
              
 <div class="col-sm-6">

              <div class="form-group">

              <label>Amount Per User</label>

              <input type="text" class="form-control"  name="amtenv" id="amtenv" required value="<?php echo $role['amtenv'];?>">

              </div>

              </div>
              

  
    
  
  


 

</select>

              </div>

              </div>






              



             <div class="clearfix"></div>   

              <div class="form-group">

              <div class="text-center">

  

 <input type="submit" class="btn btn-primary" value="Submit"  name="envelopee" ></div>

                </div> 

               </div>

                <div class="clearfix"></div>

             





          </form>

            <!-- /.box-body -->
<div class="box-body">
  <form id="formID" name="formID" method="post" action="#" enctype="multipart/form-data">
          <div class="table-responsive"> 
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                <th>Mobile</th>
                <th>Email</th>
                <th>Own Code</th>
                <th>Ref. Code</th>
              
            
                </tr>
                </thead>
                <tbody>
     <?php
  $Query=mysqli_query($con,"select * from `tbl_adminenvlop` order by id desc");
  $i=0; 
  while($row=mysqli_fetch_array($Query)){$i++;?>  
                  <tr>
              <td>https://apnaschool.online/redenvelope?reward=<?php echo @$row["id"]; ?></td>
              <td><?php echo $row['noenv'];?></td>
              <td><?php echo @$row["amtenv"]; ?></td>
            
              <td> <?php echo sprintf("%06d",@$row["id"]);?></td>
               
              
              </td>
             
              
			  
                </tr>
        <?php }?>
               
               
                </tbody>
                
              </table>
             </div>
   <div class="box-header box-header2" style="margin-bottom: 10px;">&nbsp; </div>
<div class="row">              
<div class="col-sm-10"></div>
              <div class="col-sm-2">
               &nbsp;
            </div>
              </div>
              </form>
          </div>

          <!-- /.box -->

        </div>

        <!-- /.col -->

      </div>

      <!-- /.row -->

    </section>

    <!-- /.content -->

  </div>

  <!-- /.content-wrapper -->

  

<?php  include("include/footer.inc.php");?></div>

<script>

 

	

$('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({

      checkboxClass: 'icheckbox_minimal-blue',

      radioClass: 'iradio_minimal-blue'

    });

  $(function () {

	  $(".checkbox-toggle").click(function () { 

      var clicks = $(this).data('clicks');

      if (clicks) {

        //Uncheck all checkboxes

        $("input[type='checkbox']").iCheck("uncheck");

        $(".fa", this).removeClass("fa-check-square-o").addClass('fa-square-o');

      } else {

        //Check all checkboxes

        $("input[type='checkbox']").iCheck("check");

        $(".fa", this).removeClass("fa-square-o").addClass('fa-check-square-o');

      }

      $(this).data("clicks", !clicks);

    });

    //$("#example1").DataTable();

    $('#example1').DataTable({

      "paging": true,

      "lengthChange": false,

      "searching": true,

      "ordering": false,

      "info": true,

      "autoWidth": true

    });

  });

</script>

<script type="text/javascript">

 function cancel() {

 var strconfirm = confirm("Are you sure you want to cancel ?");

           if (strconfirm == true) {

           window.location = 'manage_amount.php'; 

           }



       }

	 

</script> 

</body>
</html>