
<script type="text/javascript">function clk(){
    document.getElementById("phone").style.display = "none";
    document.getElementById("msg").style.display = "block";
    };function clk1(){ 
document.getElementById("phone").style.display = "block";
document.getElementById("msg").style.display = "none";
    };</script><BODY onLoad="clk1()">                            <style>
                              #mainDiv1{
                                 display:none;
                              }  
                              #mainDiv2{
                                 display:block;
                              }  
                               
                            </style>
                              
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Lifafa</title>

<!-- cstm css only -->
<link rel="stylesheet" href="css/style.css">
<!-- bootstrap CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<!-- google Poppins font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
<link rel="stylesheet" href="font/droid-font/stylesheet.css">
<!-- fontawesome link here --> 
<script src="https://kit.fontawesome.com/d2dea1ff6b.js"></script>
<style>
body 


.nav-bar__transparent[data-v-3d96fb60] {
  background-color: transparent
}
.nav-bar__transparent .van-icon-arrow-left[data-v-3d96fb60]:before, .nav-bar__transparent .van-nav-bar__title[data-v-3d96fb60] {
  color: #fff
}
.envelope-context[data-v-3d96fb60] {
  min-height: 100vh;
  background-color: #fefde4
}
.envelope-context .top img[data-v-3d96fb60] {
  width: 100%
}
.envelope-context .top a[data-v-3d96fb60] {
  float: right;
  position: relative;
  bottom: 15px;
  right: 15px;
  font-size: 14px
}
.main-red[data-v-3d96fb60] {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  margin-top: -15px;
  width: 60%;
  height: 42px;
  background: #62ce93;
  text-align: center;
  color: #fff;
  border-radius: 10px;
  line-height: 42px
}
.main-red[data-v-3d96fb60]:after {
  left: -6px;
  border-width: 0 0 17px 6px
}
.main-red[data-v-3d96fb60]:after, .main-red[data-v-3d96fb60]:before {
  content: "";
  display: block;
  position: absolute;
  width: 0;
  height: 0;
  top: 10px;
  border-color: #0f942c transparent;
  border-style: solid
}
.main-red[data-v-3d96fb60]:before {
  right: -6px;
  border-width: 0 6px 17px 0
}
.main-box[data-v-3d96fb60] {
  background: #fff;
  margin: 12px;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 1px 2px 1px .5px #eee
}
.redpacket-collection[data-v-3d96fb60] {
  background-image: url(/static/images/red-2.png);
  background-repeat: no-repeat;
  background-position: 50% 12px;
  background-size: auto 80%;
  text-align: center;
  z-index: 11
}
.redpacket-collection span[data-v-3d96fb60] {
  color: #79c28e;
  font-size: 30px;
  display: block;
  margin: 10px;
  padding: 36px 0
}
.redpacket-collection p[data-v-3d96fb60] {
  color: #edb456
}
.redpacket-collection-content button[data-v-3d96fb60] {
  display: inherit;
  margin: 0 auto;
  width: 55%;
  height: 39px;
  border: none;
  background-color: #f5a81e;
  border-radius: 15px;
  color: #fff;
  font-size: 16px
}
.redpacket-collection-content a[data-v-3d96fb60] {
  display: block;
  padding: 12px;
  color: #9a9a97;
  text-align: center
}
.envelope-context .bottom[data-v-3d96fb60] {
  background-repeat: no-repeat;
  background-position: 50% 12px;
  background-size: auto 80%;
  text-align: center;
  z-index: 11
}
.envelope-context .bottom span[data-v-3d96fb60] {
  color: #fab444;
  font-size: 24px;
  display: block;
  margin: 10px;
  padding: 40px 0 80px
}
.center[data-v-3d96fb60] {
  color: #9a9995
}
.bonus[data-v-3d96fb60] {
  color: #873d16
}
.envelope-context .bottom input[data-v-3d96fb60] {
  display: block;
  background-color: #fff;
  border-radius: 5px;
  border: 1px solid #eee;
  height: 50px;
  width: 85%;
  margin: 50px 14px 90px;
  padding: 0 15px;
  font-size: 14px
}
.envelope-context .bottom button[data-v-3d96fb60] {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  margin-top: -55px;
  width: 125px;
  height: 125px;
  border-radius: 50%;
  border: none;
  background-color: #f3b73f;
  color: #fff;
  font-size: 16px;
  box-shadow: inset 0 0 20px #ec9316
}
.open[data-v-3d96fb60]:after {
  width: 135px;
  height: 135px;
  box-shadow: inset 0 0 30px #facb5c
}
.open[data-v-3d96fb60]:after, .open[data-v-3d96fb60]:before {
  content: "";
  display: block;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  border-radius: 50%
}
.open[data-v-3d96fb60]:before {
  width: 145px;
  height: 145px;
  box-shadow: inset 0 0 30px #fbecac
}
.envelope-context .bottom p[data-v-3d96fb60] {
  color: #a79f9f;
  font-size: 12px;
  margin: 10px 0
}
.envelope-context .records[data-v-3d96fb60] {
  margin: 0 15px 15px;
  background: #fff;
  border-radius: 7px;
  text-align: center;
  box-shadow: 1px 2px 1px .5px #eee
}
.record-box[data-v-3d96fb60] {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 15px
}
.record-box .record-box__left[data-v-3d96fb60] {
  width: 50px
}
.record-box .record-box__center[data-v-3d96fb60] {
  flex: 1
}
.record-box .record-box__right[data-v-3d96fb60] {
  width: 70px
}
.envelope-context .records .record-box .image[data-v-3d96fb60] {
  width: 40px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right: 15px
}
.envelope-context .records .record-box .image img[data-v-3d96fb60] {
  width: 100%
}
.envelope-context .records .record-box .info[data-v-3d96fb60] {
  text-align: left
}
.envelope-context .records .record-box .info span[data-v-3d96fb60] {
  display: block;
  margin: 5px 0
}
.envelope-context .records .record-box .info .time[data-v-3d96fb60] {
  font-size: 12px;
  color: #a79f9f
}
.envelope-context .records .record-box .info .name[data-v-3d96fb60] {
  font-size: 14px
}
.envelope-context .records .record-box .money[data-v-3d96fb60] {
  color: #f3b73f;
  text-align: right;
  margin-right: 5px;
  font-size: 14px
}
.mark[data-v-3d96fb60] {
  position: fixed;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  z-index: 999;
  display: flex;
  justify-content: center;
  align-items: center;
  background: hsla(0, 0%, 100%, .5)
}
.redInfo[data-v-6241e63c] {
  width: 320px;
  height: 380px;
  border-radius: 10px;
  background: #00b8a9;
  color: #fff;
  box-shadow: 10px 10px 2px #00a799;
  margin: 35px auto 0
}
.redInfo .scrollBox[data-v-6241e63c] {
  height: 275px;
  overflow-x: hidden;
  overflow-y: scroll;
  padding: 0 10px
}
.redInfo p[data-v-6241e63c] {
  width: 160px;
  line-height: 30px;
  margin: 0 auto;
  border-bottom: 1px solid #848484;
  font-size: 14px;
  text-align: center
}
.van-checkbox[data-v-6241e63c] {
  justify-content: center !important
}
.redShow[data-v-6241e63c] {
  margin-top: 20px
}
.redShow span[data-v-6241e63c] {
  color: #83a2f6
}
.btnBox[data-v-6241e63c] {
  margin-top: 39px;
  display: flex;
  justify-content: center
}
.btnBox .btn[data-v-6241e63c] {
  display: flex;
  outline: none;
  border: none;
  justify-content: center;
  align-items: center;
  width: 185px;
  height: 32px;
  border-radius: 15px;
  background: #00b8a9;
  color: #fff
}
.imgBox[data-v-6241e63c] {
  width: 100%;
  height: 160px;
  display: flex;
  justify-content: center;
  align-items: center
}
.imgBox img[data-v-6241e63c] {
  width: 100px;
  height: 100px
}
.imgMsg[data-v-6241e63c] {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  font-size: 13px
}
.imgMsg span[data-v-6241e63c] {
  color: #848484
}
.imgMsg .btn[data-v-6241e63c] {
  width: 130px;
  height: 30px;
  border-radius: 15px;
  border: none;
  outline: none;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #00b8a9;
  color: #fff
}
.ApplyTime[data-v-6241e63c] {
  margin-top: 20px;
  height: 60px;
  border-top: 1px solid #ccc;
  display: flex;
  justify-content: space-between;
  padding: 0 15px;
  font-size: 14px;
  align-items: center
}
.putin-envelope-content[data-v-6241e63c] {
  min-height: 100vh;
  background-color: #f6f6f6
}
.putin-envelope-content .cell[data-v-6241e63c] {
  padding-top: 35px;
  margin: 0 14px 7px
}
.putin-envelope-content .errmsg[data-v-6241e63c] {
  text-align: center;
  color: red
}
.envelope-btn[data-v-6241e63c] {
  display: block;
  width: 100%;
  padding: 0 6px;
  margin-top: 20px;
  box-sizing: border-box;
  text-align: center
}
.envelope-btn button[data-v-6241e63c] {
  width: 75%;
  margin: 0 auto;
  height: 40px;
  font-size: 16px;
  color: #fff;
  background-color: #f3b73f;
  border: 0;
  border-radius: 30px;
  box-shadow: 0 3px 0 0 #c8952a
}
.envelope-btn button[data-v-6241e63c]:disabled {
  background-color: #dbdbdb;
  box-shadow: 0 3px 0 0 #707070
}
.popup-header[data-v-6241e63c] {
  background: #00b8a9;
  line-height: 35px;
  height: 35px;
  color: #fff;
  border-radius: 0 0 50% 50%
}
.popup-header_amount[data-v-6241e63c] {
  font-size: 20px;
  font-weight: 750;
  margin-top: 10px
}
.popup-password[data-v-6241e63c] {
  text-align: left;
  text-indent: 20px;
  font-size: 15px;
  margin: 13px
}
.popup-password-input[data-v-6241e63c] {
  width: 80%;
  border: 1px solid #eee;
  line-height: 29px
}
.bottom_box[data-v-6241e63c] {
  display: flex;
  width: 100%
}
.bottom-cancel[data-v-6241e63c] {
  font-size: 16px;
  background-color: #828282;
  margin-top: 12px;
  flex: 1;
  color: #fff
}
.bottom-confirm[data-v-6241e63c] {
  font-size: 16px;
  background-color: #f3b73f;
  margin-top: 12px;
  flex: 1;
  color: #fff
}
.cell .yd-cell-box[data-v-6241e63c] {
  margin-bottom: 20px
}
.yd-cell[data-v-6241e63c] {
  background-color: #fff;
  position: relative;
  height: 50px;
  line-height: 50px;
  z-index: 5
}
.yd-cell-item[data-v-6241e63c] {
  background-color: #fff;
  display: flex;
  position: relative;
  padding-left: 6px;
  overflow: hidden
}
.yd-cell-left[data-v-6241e63c] {
  color: #333;
  font-size: 14px;
  white-space: nowrap;
  display: flex;
  align-items: center
}
.yd-cell-right[data-v-6241e63c] {
  flex: 1;
  width: 100%;
  min-height: 24px;
  color: #525252;
  text-align: right;
  font-size: 14px;
  padding-right: 8px;
  display: flex;
  align-items: center;
  justify-content: flex-end
}
.yd-cell-arrow[data-v-6241e63c]:after {
  margin-left: 5px;
  margin-right: -.1152rem;
  display: block;
  font-family: YDUI-INLAY;
  font-size: .4896rem;
  color: #c9c9c9;
  content: "\e608"
}
.popup[data-v-6241e63c] {
  text-align: center;
  padding: 10px;
  z-index: 2002;
  width: 85%
}
.mark[data-v-6241e63c] {
  position: fixed;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  z-index: 999;
  display: flex;
  justify-content: center;
  align-items: center;
  background: hsla(0, 0%, 100%, .5)
}
.goVerify[data-v-6241e63c] {
  position: relative;
  min-height: calc(100vh - 46px);
  background: #fff;
  width: 100%
}
.goVerifyMain[data-v-6241e63c] {
  width: 80%;
  position: absolute;
  top: 40%;
  left: 50%;
  transform: translate(-50%, -45%);
  background: #fff
}
.goVerifyMainBtn[data-v-6241e63c] {
  border: none;
  width: 100%;
  margin-top: 40px;
  line-height: 45px;
  height: 45px;
  color: #fff;
  border-radius: 8px;
  background: #00b8a9
}
.goVerifyMainTitem[data-v-6241e63c] {
  width: 100%;
  line-height: 26px;
  word-break: break-all
}
.group-button[data-v-6241e63c] {
  background: #00b8a9;
  border: 1px solid #00b8a9
}
.redrecord-content .redrecord-box[data-v-6f8aa97a] {
  margin: 0 20px 10px;
  padding: 10px;
  font-size: 14px;
  background-color: #fff
}
.redrecord-content .redrecord-box .other[data-v-6f8aa97a] {
  display: flex;
  align-items: center
}
.redrecord-content .redrecord-box .other .left[data-v-6f8aa97a] {
  width: 35%
}
.redrecord-content .redrecord-box .other .left span[data-v-6f8aa97a] {
  display: block
}
.redrecord-content .redrecord-box .other .left .money__row[data-v-6f8aa97a] {
  color: #00b8a9;
  font-size: 24px;
  word-break: break-word
}
.redrecord-content .redrecord-box .other .left .money__row em[data-v-6f8aa97a] {
  font-size: 14px;
  margin-right: 5px
}
.redrecord-content .redrecord-box .other .left .money__row .small[data-v-6f8aa97a] {
  color: #00b8a9;
  font-size: 14px;
  display: inline
}
.redrecord-content .redrecord-box .other .left .received[data-v-6f8aa97a] {
  color: #828282;
  padding-top: 8px;
  font-size: 12px
}
.redrecord-content .redrecord-box .other .right[data-v-6f8aa97a] {
  width: 65%
}
.redrecord-content .redrecord-box .other .right .right-box[data-v-6f8aa97a] {
  margin: 0 auto;
  position: relative
}
.redrecord-content .redrecord-box .other .right .type[data-v-6f8aa97a] {
  color: #000;
  font-size: 16px
}
.redrecord-content .redrecord-box .other .right .time[data-v-6f8aa97a] {
  color: #828282;
  font-size: 13px;
  margin-top: 8px
}
.redrecord-content .redrecord-box .other .right .time span[data-v-6f8aa97a] {
  display: block;
  margin: .1rem
}
.redrecord-content .redrecord-box .other .right img[data-v-6f8aa97a] {
  width: 70px;
  position: absolute;
  top: 10px;
  right: 0
}
.envelope-context[data-v-79af45f2] {
  min-height: 100vh;
  background-color: #f6f6f6
}
.order-outer-content[data-v-79af45f2] {
  position: relative
}
.top-selete[data-v-79af45f2] {
  display: flex;
  margin: 20px 15px 0;
  border: 1px solid #00b8a9;
  border-radius: 5px
}
.top-selete-sub[data-v-79af45f2] {
  flex: 1;
  padding: 8px 0;
  text-align: center;
  font-size: 14px;
  color: #00b8a9;
  background-color: transparent
}
.top-selete-sub.active[data-v-79af45f2] {
  font-size: 14px;
  color: #fff;
  background-color: #00b8a9
}
.reservation-chunk[data-v-79af45f2] {
  display: flex;
  padding: 10px 10px 7px
}
.reservation-chunk-sub[data-v-79af45f2] {
  flex: 1;
  text-align: center
}
.reservation-chunk-sub-title[data-v-79af45f2] {
  padding: 2px 0 10px;
  font-size: 13px;
  color: #989898
}
.reservation-chunk-sub-num[data-v-79af45f2] {
  font-size: 24px;
  color: #00b8a9
}
.reservation-chunk-sub-num span[data-v-79af45f2] {
  font-size: 15px
}
.reservation-booking[data-v-79af45f2] {
  background-color: #fff;
  margin-bottom: 18px
}
.booking-title[data-v-79af45f2] {
  display: flex;
  justify-content: space-between;
  padding: 18px;
  font-size: 14px;
  font-weight: 700;
  color: #13347b;
  border-bottom: 1px solid #eee
}
.booking-title-no[data-v-79af45f2] {
  font-size: 14px;
  font-weight: 700;
  color: #151515
}
.booking-title-no span[data-v-79af45f2] {
  font-size: 14px;
  font-weight: 500;
  color: #7d7d7d
}
.booking-info[data-v-79af45f2] {
  display: flex;
  padding: 15px;
  border-bottom: 1px solid #eee
}
.booking-info-img[data-v-79af45f2] {
  display: block;
  width: 30px
}
.booking-info-img img[data-v-79af45f2] {
  width: 100%;
  height: 100%
}
.booking-info-detail[data-v-79af45f2] {
  padding: 0 10px
}
.booking-info-title[data-v-79af45f2] {
  font-size: 14px;
  font-weight: 700
}
.booking-info-quantity[data-v-79af45f2] {
  display: flex;
  justify-content: space-between;
  padding: 2px 0;
  font-size: 14px
}
.booking-info-quantity span[data-v-79af45f2] {
  display: block;
  font-weight: 600
}
.booking-info-text[data-v-79af45f2] {
  font-size: 14px;
  padding: 2px 0
}
.booking-info-view[data-v-79af45f2] {
  font-size: 14px;
  color: #b52626;
  text-decoration: underline
}
.booking-bottom[data-v-79af45f2] {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px
}
.booking-bottom-text[data-v-79af45f2] {
  font-size: 14px
}
.booking-bottom-text span[data-v-79af45f2] {
  display: block;
  font-size: 14px;
  color: #828282
}
.booking-bottom-btn[data-v-79af45f2] {
  display: flex
}
.booking-bottom-btn-sub[data-v-79af45f2] {
  min-width: 60px;
  padding: 18px 15px;
  margin: 0 5px;
  font-size: 14px;
  font-weight: 600;
  background-color: #f2f2f2;
  border: 0;
  border-radius: 14px;
  display: inline-block
}
.colorg[data-v-79af45f2] {
  color: #00b8a9
}
.colorr[data-v-79af45f2] {
  color: #b52626
}

.van-nav-bar__title {
    max-width: 60%;
    margin: 0 auto;
    color: #323233;
    font-weight: 500;
    font-size: 16px;
}
.van-ellipsis {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.van-nav-bar {
    position: relative;
    z-index: 1;
    line-height: 22px;
    text-align: center;
    background-color: #fff;
    -webkit-user-select: none;
    user-select: none;
}

element.style {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 15px;
}
.record-box[data-v-3d96fb60] {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 15px;
}
.envelope-context .records[data-v-3d96fb60] {
    margin: 0 15px 15px;
    background: #fff;
    border-radius: 7px;
    text-align: center;
    box-shadow: 1px 2px 1px 0.5px #eee;
}
.envelope-context .records .record-box .image img[data-v-3d96fb60] {
    width: 100%;
}
img {
    max-width: 100%;
    display: block;
}
.envelope-context .records[data-v-3d96fb60] {
    margin: 0 15px 15px;
    background: #fff;
    border-radius: 7px;
    text-align: center;
    box-shadow: 1px 2px 1px 0.5px #eee;
}






{
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, Helvetica Neue, Helvetica, Segoe UI, Arial, Roboto, PingFang SC, miui, Hiragino Sans GB, Microsoft Yahei, sans-serif;
}
.van-nav-bar__title {
    max-width: 60%;
    margin: 0 auto;
    color: #323233;
    font-weight: 500;
    font-size: 16px;
}
.van-ellipsis {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.van-nav-bar {
    position: relative;
    z-index: 1;
    line-height: 22px;
    text-align: center;
    background-color: #fff;
    -webkit-user-select: none;
    user-select: none;
}

element.style {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 15px;
}
.record-box[data-v-3d96fb60] {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 15px;
}
.envelope-context .records[data-v-3d96fb60] {
    margin: 0 15px 15px;
    background: #fff;
    border-radius: 7px;
    text-align: center;
    box-shadow: 1px 2px 1px 0.5px #eee;
}
.envelope-context .records .record-box .image img[data-v-3d96fb60] {
    width: 100%;
}
img {
    max-width: 100%;
    display: block;
}
.envelope-context .records[data-v-3d96fb60] {
    margin: 0 15px 15px;
    background: #fff;
    border-radius: 7px;
    text-align: center;
    box-shadow: 1px 2px 1px 0.5px #eee;
}


.navbar {
  overflow: hidden;
  display:flex;
  justify-content:center;
  align-items:center;
  background-color: #65A765;
  position: fixed; /* Set the navbar to fixed position */
  top: 0; /* Position the navbar at the top of the page */
  width: 100%; /* Full width */
}
.cus-img{
		width: 1.6rem;
		height:1.6rem;
	}
</style>
</head>

<!-- main nav code here -->

<body>
<div data-v-31a77878="" class="layout-content"><!---->
  <div data-v-3d96fb60="" class="envelope-context">
    <div data-v-3d96fb60="" class="nav-bar__transparent van-nav-bar van-nav-bar--fixed">
      <div class="van-nav-bar__content">
        
        <div class="bg-success d-flex shadow-sm px-3 py-2">
            <a href="/myaccount.php">
<img  src="images/left-chevron.png" class="img-fluid cus-img" alt=""></a>
<h4 class="text-center w-100">Red-Envelope</h4>
</div>
      </div>
    </div>
    <div data-v-3d96fb60="">
      <div data-v-3d96fb60="" class="top"><img data-v-3d96fb60="" src="red-001.jpg"></div>
      <div data-v-3d96fb60="" class="main-red ">Red Envelope</div>
      <div data-v-3d96fb60="" class="main-box" id="mainDiv1" >
        <div data-v-3d96fb60="" class="bottom" > <span data-v-3d96fb60="" id="msg" class="center">FINISHED</br> Collected</span>
          <form action="" method="POST"  >
            <input data-v-3d96fb60="" type="tel" name="phone" id="phone"  maxlength="10" placeholder="Enter Phone Number" autocomplete="off"  value="" >
            <button data-v-3d96fb60="" name="submit" class="open" >OPEN ENVELOPE</button>
          </form>
        </div>
        <div data-v-3d96fb60="" style="position: absolute; right: 0px; margin-right: 12px;"> <a href="javascript:void(0)" class="d-none" data-v-3d96fb60="" style="display: block; padding: 12px; color: rgb(154, 154, 151); text-align: center;" id="copy" onClick="copy();">Copy Link</a> </div>
      </div>
      
      
      <!--second data start-->
      
      <div  class="" id="mainDiv2" data-v-3d96fb60=""><div data-v-3d96fb60=""  class="redpacket-collection main-box " ><span data-v-3d96fb60="">
                    FINISHED</br> Collected                </span> <!----></div> <div data-v-3d96fb60="" class="redpacket-collection-content "><button data-v-3d96fb60="" style="margin-bottom: 15px;">MY RED ENVELOPES</button></div>
                                <div data-v-3d96fb60="" id="mainDiv3" class="record-box  bg-white" style="display: flex; justify-content: center; align-items: center; padding: 15px;">
          
          
          
          
          <div data-v-3d96fb60="" class="record-box__left">
              <div data-v-3d96fb60="" class="image">
                  <img data-v-3d96fb60="" src="user-1.png">
                  </div></div> 
                  
                  
                  
                  
                  
                  
                  <div data-v-3d96fb60="" class="record-box__center ms-3"><div data-v-3d96fb60="" class="info">
                      <span data-v-3d96fb60="" class="name"> Member7323</span> <span data-v-3d96fb60="" class="time d-block"> 09-10-2022 12:10:26 pm</span>
                      </div></div> 
                      <div data-v-3d96fb60="" class="record-box__right"><span data-v-3d96fb60="" style="font-size: 16px; color: rgb(122, 196, 140);">₹  10</span>
                      </div></div>
                      
                                          
                </div>
      <!--second data end-->
      <!--listdata strat-->
      
      <!----></div>
    <!----></div>
</div>
<script async="" src=""></script> 
<script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'UA-154573245-1');
    </script> 
<script type="text/javascript" src="/chunk.corejs.def07d02.js"></script><script type="text/javascript" src="/chunk.vantjs.def07d02.js"></script><script type="text/javascript" src="/chunk.vendor.def07d02.js"></script><script type="text/javascript" src="/main.def07d02.js"></script> 
<script>
    // function Copy(){
    //     var abc = window.location.href;
    //     navigator.clipboard.writeText(abc.value);
    // }


function copy() {
  var copyText = window.location.href;
  copyText.select();
  document.execCommand("copy");
}

document.querySelector("#copy").addEventListener("click", copy);

</script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<!--owl carousel--> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
