<?php
ob_start();
session_start();
include("include/connection.php");



 @$email=$_POST['mobile'];
 @$uniqueid=$_POST['envcode'];

$upp = mysqli_query($con , "SELECT * FROM `users` WHERE  username='$email'");
   // $rupap = mysqli_fetch_array($upp);  
  $userid = $rupap['id'] ;
  //@$name=$_POST['username'];
 @$emaila=$_POST['email'];
 @$mobilea=$_POST['username'];
  
	$upp = mysqli_query($con , "SELECT * FROM `tbl_adminenvlop` WHERE  id='$uniqueid'");
    $rupap = mysqli_fetch_array($upp);         
   $nofred = $rupap['noenv']  ;
   $amtred = $rupap['amtenv']  ;
   $fnofred = ($nofred-1);
   
   
   $chkbankdetailQuery=mysqli_query($con,"select * from `tbl_envelop` where `userid`='".$userid."'");
$bankdetailRows=mysqli_num_rows($chkbankdetailQuery);
if($bankdetailRows=='')
{
 if($nofred>0){  

$withdrawalsql= mysqli_query($con,"INSERT INTO `tbl_envelop`(`userid`,`name`,`email`,`mobile`,`amount`,`status`,`rechargestatus`,`createdate`) VALUES ('".$id."','".$name."','".$emaila."','".$username."','".$amtred."','1','1','".$today."')");

      
           	$upp = mysqli_query($con , "SELECT * FROM `users` WHERE `username` = '$userid'");
    $rupap = mysqli_fetch_array($upp);         
   $weamt = $rupap['balance'];
   
 echo  $totalamt = ( $amtred + $weamt);
  $today = date("Y-m-d H:i:s");
$wall = mysqli_query($con, "UPDATE `users` SET `balance` = '$totalamt' WHERE `userid` = '$userid'");
    	$wallint = mysqli_query($con, "UPDATE `tbl_adminenvlop` SET noenv = noenv-1 WHERE `id` = '$uniqueid'");
    	
    	
    $sql3= mysqli_query($con,"INSERT INTO `users`(`userid`,`orderid`,`balance`,`type`,`actiontype`,`createdate`) VALUES ('".$userid."','".$orderid."','".$amtred."','credit','envelope','".$today."')");	
    echo '<script language="javascript">';

}else{
    echo 'kahatam hogyaa ';
}

}
else{
   
header("Location: popup.php");
exit();
    echo 'allready';
   
}




   
        ?>
        

        